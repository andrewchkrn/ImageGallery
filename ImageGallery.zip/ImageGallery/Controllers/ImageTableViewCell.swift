//
//  ImageTableViewCell.swift
//  CookiesRule
//
//  Created by Andrew Trach on 20.02.2021.
//

import UIKit

class ImageTableViewCell: UITableViewCell {
    
    @IBOutlet weak var itemsImageView: UIImageView!
    
}
