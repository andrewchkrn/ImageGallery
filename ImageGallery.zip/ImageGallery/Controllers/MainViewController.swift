//
//  ViewController.swift
//  CookiesRule
//
//  Created by Andrew Trach on 19.02.2021.
//

import UIKit
import SDWebImage
import CCBottomRefreshControl

class ImagesViewController: UIViewController {
    
    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(requestData), for: .valueChanged)
        return refreshControl
    }()
    lazy var bottomRefreshControl: UIRefreshControl = {
        let bottomRefreshControl = UIRefreshControl()
        bottomRefreshControl.triggerVerticalOffset = 100
        bottomRefreshControl.addTarget(self, action: #selector(pagination), for: .valueChanged)
        return bottomRefreshControl
    }()
    
    private let networkManager = NetworkManager()
    private var data: DataModel?
    private var results = [Results]()
    private var accessToken: String?
    private var page = 1
    
    @IBOutlet weak var tableView: UITableView!
    
    private var isLoading = false {
        didSet {
            isLoading ? refreshControl.beginRefreshing() : refreshControl.endRefreshing()
        }
    }
    
    // MARK: - Controller lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getToken()
        tableView.refreshControl = refreshControl
        tableView.bottomRefreshControl = bottomRefreshControl
    }
    
    // MARK: - Private func
    
    private func getToken() {
        networkManager.getToken() { [weak self] (accesToken) in
            self?.getImage()
        } failure: {
            print("fail getToken")
        }
    }
    
    private func getNextImage(offset: Int) {
        isLoading = true
        networkManager.getNextImage(offset: offset) { [weak self] (imagesModel) in
            self?.isLoading = false
            self?.data = imagesModel
            self?.results += imagesModel.results
            self?.tableView.reloadData()
        } failure: { [weak self] (error) in
            print(error.text)
            self?.isLoading = false
        }
    }
    
    private func getImage() {
        isLoading = true
        networkManager.getImage() { [weak self] (imagesModel) in
            self?.isLoading = false
            self?.data = imagesModel
            self?.results = imagesModel.results
            self?.tableView.reloadData()
        } failure: { [weak self] (error) in
            self?.isLoading = false
            print(error.text)
        }
    }
    
    @objc private func requestData() {
        print("startRefreshing")
        getImage()
    }
    
    @objc private func pagination() {
        print("startRefreshing")
        let deadline = DispatchTime.now() + .milliseconds(700)
        DispatchQueue.main.asyncAfter(deadline: deadline) {
            self.bottomRefreshControl.endRefreshing()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toDetailSegue" {
            if let vc = segue.destination as? DetailViewController,
               let results = sender as? Results {
                vc.result = results
            }
        }
    }
}

// MARK: - UITableViewDataSource

extension ImagesViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return results.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ImageTableViewCell", for: indexPath) as! ImageTableViewCell
        let images = results[indexPath.row]
        let image = images.content?.image ?? ""
        let url = URL(string: image)
        cell.itemsImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "placeholder.png"))
       
        return cell
    }
}

// MARK: - UITableViewDelegate

extension ImagesViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let result = results[indexPath.row]
        performSegue(withIdentifier: "toDetailSegue", sender: result)
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        let lastItem = indexPath.row == results.count - 1
        if lastItem
            && data?.hasMore ?? false
            && !isLoading {
            page += 1
            getNextImage(offset: data?.nextOffset ?? 20 )
        }
    }
}
