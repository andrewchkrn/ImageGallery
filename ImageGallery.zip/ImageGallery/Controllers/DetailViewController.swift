//
//  DetailViewController.swift
//  CookiesRule
//
//  Created by Andrew Trach on 23.02.2021.
//

import UIKit
import SDWebImage

class DetailViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var likeTextField: UILabel!
    @IBOutlet weak var authorTextField: UILabel!
    
    var result: Results!
    
    // MARK: - Controller lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        authorTextField.text = result.author?.username ?? " "
        let image = result?.content?.image ?? ""
        let url = URL(string: image)
        imageView.sd_setImage(with: url, completed: nil)
        likeTextField.text = String(result.stats?.favourites ?? 0)
    }
    
    // MARK: - @IBAction func
    
    @IBAction func downloadButtonAction(_ sender: Any) {
        if let url = URL(string: result.content?.image ?? ""),
                let data = try? Data(contentsOf: url),
                let image = UIImage(data: data) {
                UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
            self.showToast(message: "Downloading image to gallery", font: .systemFont(ofSize: 12.0))
            }
        }
    }

