//
//  UserSesion.swift
//  CookiesRule
//
//  Created by Andrew Trach on 20.02.2021.
//

import UIKit

class UserSession: NSObject {
    
    enum Keys: String {
        case token
     
    }
    
    var token: String? {
        get {
            UserDefaults.standard.string(forKey: Keys.token.rawValue)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: Keys.token.rawValue)
            UserDefaults.standard.synchronize()
        }
    }
    
    static var shared: UserSession = UserSession()
    
    private override init() {
        super.init()
    }
    


}


