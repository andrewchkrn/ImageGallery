//
//  Images.swift
//  CookiesRule
//
//  Created by Andrew Trach on 22.02.2021.
//

import Foundation


struct DataModel {

    var results = [Results]()
    let hasMore: Bool
    let nextOffset: Int
    
    init?(dict: [String: Any]) {
        guard let hasMore = dict["has_more"] as? Bool,
              let nextOffset = dict["next_offset"] as? Int,
              let results = dict["results"] as? [[String: Any]]
        else {
            return nil
        }

        for resultsDict in results {
            if let resultData = Results(dict: resultsDict) {
                self.results.append(resultData)
            }
        }

        self.hasMore = hasMore
        self.nextOffset = nextOffset
       
    }
}

struct Results {

    var author: Author?
    var stats: Stats?
    var content: Content?
  
    init?(dict: [String: Any]) {
        guard  let author = dict["author"] as? [String: Any],
               let stats = dict["stats"] as? [String: Any],
               let content = dict["content"] as? [String: Any] else {
            return nil
        }
        
        self.author = Author(dict: author)
        self.stats = Stats(dict: stats)
        self.content = Content(dict: content)
    }
}

struct Author {
    var username: String
  
    init?(dict: [String: Any]) {
        guard let username = dict["username"] as? String
        else {
            return nil
        }
       
        self.username = username
    }
}

struct Stats {
    var favourites: Int
  
    init?(dict: [String: Any]) {
        guard let favourites = dict["favourites"] as? Int
        else {
            return nil
        }
       
        self.favourites = favourites
    }
}

struct Content {
    var image: String
  
    init?(dict: [String: Any]) {
        guard let image = dict["src"] as? String
        else {
            return nil
        }
       
        self.image = image
    }
}
