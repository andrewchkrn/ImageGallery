//
//  Networkmaneger.swift
//  CookiesRule
//
//  Created by Andrew Trach on 20.02.2021.
//


import Alamofire
import Foundation


struct AppError: Error {
    var text: String
}

class NetworkManager {
    
    let baseUrl = "https://www.deviantart.com/"
    let clientId = "14872"
    let clientSecret = "30e3b9ee892dd297ab0227d9c2a48d4d"
    let grantType = "client_credentials"
    
    
    
    func getToken(success: @escaping (String) -> (),
                  failure: @escaping () -> ()) {
        
        let dict = ["clientId": clientId,
                    "clientSecret": clientSecret,
                    "grantType": grantType]
        
        AF.request(baseUrl + "oauth2/token?client_id=\(clientId)&client_secret=\(clientSecret)&grant_type=\(grantType)",
                   method: .post,
                   parameters: dict,
                   encoder: JSONParameterEncoder.default).responseJSON { response in
                    if let dict = response.value as? [String: Any],
                       let accessToken = dict["access_token"] as? String {
                        UserSession.shared.token = accessToken
                        print(dict)
                        print(accessToken)
                        success(accessToken)
                    }
                   }
    }
    
    func getImage(success: @escaping (DataModel) -> (),
                  failure: @escaping (AppError) -> ()) {
        guard let token = UserSession.shared.token else { return }
        AF.request(baseUrl + "api/v1/oauth2/browse/newest?limit=30&offset=20&access_token=\(token)").responseJSON { response in
            if let error = self.observeError(with: response.value) {
                failure(error)
            } else if let dict = response.value as? [String: Any],
                      let myReferal = DataModel(dict: dict) {
                success(myReferal)
            } else {
                failure(AppError.init(text: "Some error"))
            }
        }
    }
    func getNextImage(offset: Int, success: @escaping (DataModel) -> (),
                  failure: @escaping (AppError) -> ()) {
        guard let token = UserSession.shared.token else { return }
        AF.request(baseUrl + "api/v1/oauth2/browse/newest?limit=30&offset=\(offset)&access_token=\(token)").responseJSON { response in
            if let error = self.observeError(with: response.value) {
                failure(error)
            } else if let dict = response.value as? [String: Any],
                      let myReferal = DataModel(dict: dict) {
                success(myReferal)
            } else {
                failure(AppError.init(text: "Some error"))
            }
        }
    }
    
    func observeError(with response: Any?) -> AppError? {
        if let dict = response as? [String: Any],
           let error = dict["error"] as? String {
            return AppError(text: error)
        }
        return nil
    }
}
